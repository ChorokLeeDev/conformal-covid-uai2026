# Code for: Diagnosing Conformal Prediction Failures Under Distribution Shift: A COVID-19 Case Study

## Requirements
- Python 3.9+
- LightGBM, SHAP, scikit-learn, scipy, statsmodels, pandas, numpy
- RelBench (for SALT dataset): `pip install relbench`

## Reproduction Steps

### 1. Main experiment (50-seed ensemble on SALT)
```bash
python run_50seed_ensemble.py
```

### 2. SHAP concentration computation
```bash
python compute_shap_concentration_all_tasks.py
```

### 3. Shift detection baselines (MMD, C2ST)
```bash
python run_mmd_c2st_comparison.py
```

### 4. Adaptive Conformal Inference (ACI)
```bash
python run_aci_all_tasks.py
```

### 5. External dataset validation
```bash
python run_external_multiseed.py
```

### 6. Statistical analysis (ICC, partial correlation)
```bash
python compute_icc_and_partial.py
```

## Dataset
The SALT dataset is publicly available via RelBench:
```python
from relbench.datasets import get_dataset
dataset = get_dataset("rel-salt", download=True)
```
